# Build59 third-pair escape diagnostic

Build59 reproduces the complete Build58 blind bank, probes every frozen second-pair sibling for one-coordinate +/-1px locality using proposal only, and applies the bounded coupled pair stencil only at proposal-local siblings. The entire B/mild+B/angle bank is frozen before qualification/HMAC; SIFT/reference geometry is post-hoc only.

## Post-hoc summary

| image | target | pair | seed px | baseline px | sibling parents | local parents | third-pair states | best parent px | best pair px | pair qualified | pair HMAC | qualified gain | interpretation |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|
| phone-b-mild.jpg | 10 | top+left | 34.048 | 43.168 | 275 | 50 | 180 | 26.149 | 25.407 | true | false | true | third-pair-qualified-gain |
| phone-b-angle.jpg | 18 | top+bottom | 5448.391 | 5453.906 | 0 | 0 | 0 | n/a | n/a | n/a | n/a | false | third-pair-not-triggered |

Interpretation is post-hoc only. `third-pair-recovery` requires HMAC authentication. `third-pair-qualified-gain` requires a frozen pair escape to improve both proposal and independent oracle error relative to its exact Build58 sibling parent while passing unchanged qualification. No label changes production behavior.
