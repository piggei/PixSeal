# PixSeal Build64 deep-recovery production-candidate matrix

Build64 preserves every Build44-qualified path and adds the frozen Build63 deep recovery only as a final fallback after all existing phone decode paths fail.

| image | role | geometry | data | Build43 attempted | B43 frozen | B43 qualified | B43 auth | B64 attempted | B64 bank | B64 qualified | B64 auth | HMAC | payload | qualification |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| phone-control-front.jpg | control | false | false | true | 28 | 0 | false | true | 26 | 0 | false | false | - | PASS |
| phone-control-mild.jpg | control | false | true | true | 32 | 0 | false | true | 810 | 6 | false | false | - | PASS |
| phone-control-angle.jpg | control | false | false | true | 32 | 0 | false | true | 11 | 0 | false | false | - | PASS |
| phone-a-front.jpg | required-build43 | true | true | true | 32 | 8 | true | false | 0 | 0 | false | true | true | PASS |
| phone-a-mild.jpg | required-any | true | true | false | 0 | 0 | false | false | 0 | 0 | false | true | true | PASS |
| phone-a-angle.jpg | required-direct | true | true | false | 0 | 0 | false | false | 0 | 0 | false | true | true | PASS |
| phone-b-front.jpg | required-direct | true | true | false | 0 | 0 | false | false | 0 | 0 | false | true | true | PASS |
| phone-b-mild.jpg | required-build64 | true | true | true | 32 | 1 | false | true | 937 | 935 | true | true | true | PASS |
| phone-b-angle.jpg | required-reject | false | false | true | 28 | 1 | false | true | 6198 | 0 | false | false | false | PASS |

Required gate: controls reject; all Build44 required passes remain authenticated without Build64; B/mild authenticates through Build64; B/angle remains rejected.
