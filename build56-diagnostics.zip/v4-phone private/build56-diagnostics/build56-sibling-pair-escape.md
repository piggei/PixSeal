# Build56 sibling pair-escape diagnostic

Build56 reproduces the complete Build55 blind sibling bank. Every frozen sibling is first tested against the complete independent +/-1px single-coordinate stencil using the unchanged proposal score. Only siblings with zero proposal-improving single-coordinate neighbors receive the bounded 112-state coupled +/-1px pair stencil; at most eight pair states are retained by proposal. The complete bank is frozen before held-out/full-pilot qualification or HMAC. SIFT/reference geometry is post-hoc only.

## Post-hoc summary

| image | target | pair | seed px | baseline px | siblings | local siblings | pair states | best parent px | best pair px | pair qualified | pair HMAC | qualified gain | interpretation |
|---|---:|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|---|
| phone-b-mild.jpg | 10 | top+left | 34.049 | 43.168 | 91 | 16 | 65 | 29.778 | 28.514 | true | false | true | sibling-pair-qualified-gain |
| phone-b-angle.jpg | 18 | top+bottom | 5448.391 | 5453.906 | 0 | 0 | 0 | n/a | n/a | n/a | n/a | false | sibling-pair-not-triggered |

Interpretation is post-hoc only. `sibling-pair-recovery` requires HMAC authentication. `sibling-pair-qualified-gain` requires a frozen pair state to improve both proposal and independent oracle error relative to its exact Build55 sibling parent while passing unchanged qualification. No label changes production behavior.
