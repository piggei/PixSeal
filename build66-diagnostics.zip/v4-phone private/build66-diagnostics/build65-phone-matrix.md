# PixSeal Build66 ordered parallel decode equivalence/performance matrix

Build66 preserves the qualified Build64 semantics exactly, keeps Build65 seed-parallel geometry, and additionally evaluates qualified protected-data candidates in deterministic ordered parallel batches.

| image | role | geometry | B43 auth | B64 evals | B64 bank | B64 qual | B64 decode | B64 frames | B65 seed workers | B66 decode workers | HMAC | payload | telemetry eq | ms | B65 ms | speedup | qualification |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| phone-control-front.jpg | control | false | false | 18021 | 26 | 0 | 0 | 0 | 8 | 0 | false | - | true | 124080 | 118644 | 0.956 | PASS |
| phone-control-mild.jpg | control | false | false | 117609 | 810 | 6 | 6 | 18432 | 8 | 6 | false | - | true | 417928 | 362530 | 0.867 | PASS |
| phone-control-angle.jpg | control | false | false | 21203 | 11 | 0 | 0 | 0 | 8 | 0 | false | - | true | 110621 | 121804 | 1.101 | PASS |
| phone-a-front.jpg | required-build43 | true | true | 0 | 0 | 0 | 0 | 0 | 0 | 0 | true | true | true | 43744 | 40464 | 0.925 | PASS |
| phone-a-mild.jpg | required-any | true | false | 0 | 0 | 0 | 0 | 0 | 0 | 0 | true | true | true | 15223 | 16511 | 1.085 | PASS |
| phone-a-angle.jpg | required-direct | true | false | 0 | 0 | 0 | 0 | 0 | 0 | 0 | true | true | true | 15144 | 17196 | 1.135 | PASS |
| phone-b-front.jpg | required-direct | true | false | 0 | 0 | 0 | 0 | 0 | 0 | 0 | true | true | true | 13723 | 14330 | 1.044 | PASS |
| phone-b-mild.jpg | required-build66 | true | false | 79259 | 937 | 935 | 691 | 2120047 | 8 | 8 | true | true | true | 544038 | 828036 | 1.522 | PASS |
| phone-b-angle.jpg | required-reject | false | false | 334857 | 6198 | 0 | 0 | 0 | 8 | 0 | false | false | true | 891186 | 852740 | 0.957 | PASS |

Required gate: complete Build64 outcome equivalence, exact deep-bank/evaluation/logical-decode telemetry on every fallback case, Build65 seed-parallel and Build66 ordered-decode telemetry on every deep fallback, and the nine-photo qualification matrix remains PASS. Timing and speedup are reported separately and do not affect correctness.
