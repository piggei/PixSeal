# PixSeal Build65 deterministic seed-parallel equivalence matrix

Build65 preserves the qualified Build64 search/decode semantics exactly, but schedules the 24 independent deep-recovery seeds concurrently and reassembles them in original seed order.

| image | role | geometry | B43 auth | B64 evals | B64 bank | B64 qual | B64 decode | B64 frames | B65 workers | HMAC | payload | telemetry eq | ms | qualification |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| phone-control-front.jpg | control | false | false | 18021 | 26 | 0 | 0 | 0 | 8 | false | - | true | 118644 | PASS |
| phone-control-mild.jpg | control | false | false | 117609 | 810 | 6 | 6 | 18432 | 8 | false | - | true | 362530 | PASS |
| phone-control-angle.jpg | control | false | false | 21203 | 11 | 0 | 0 | 0 | 8 | false | - | true | 121804 | PASS |
| phone-a-front.jpg | required-build43 | true | true | 0 | 0 | 0 | 0 | 0 | 0 | true | true | true | 40464 | PASS |
| phone-a-mild.jpg | required-any | true | false | 0 | 0 | 0 | 0 | 0 | 0 | true | true | true | 16511 | PASS |
| phone-a-angle.jpg | required-direct | true | false | 0 | 0 | 0 | 0 | 0 | 0 | true | true | true | 17196 | PASS |
| phone-b-front.jpg | required-direct | true | false | 0 | 0 | 0 | 0 | 0 | 0 | true | true | true | 14330 | PASS |
| phone-b-mild.jpg | required-build65 | true | false | 79259 | 937 | 935 | 691 | 2120047 | 8 | true | true | true | 828036 | PASS |
| phone-b-angle.jpg | required-reject | false | false | 334857 | 6198 | 0 | 0 | 0 | 8 | false | false | true | 852740 | PASS |

Required gate: complete Build64 outcome equivalence, exact deep-bank/evaluation/decode telemetry on every fallback case, Build65 parallel telemetry present only when deep recovery runs, and the nine-photo qualification matrix remains PASS.
